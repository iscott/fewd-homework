$(document).ready(function(){


  alert("Wait, don't leave this page yet. Click here for a special offer!")
  $("h1").click(
    function(){
      alert("You clicked the headline")
    }
  )


});

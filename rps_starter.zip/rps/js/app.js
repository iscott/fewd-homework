// This waits till the page finishes loading before running the code inside the {}
$(document).ready(function() {

  alert("test")

});
